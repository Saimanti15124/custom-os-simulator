# Custom OS Simulator 🖥️

A **UNIX-style mini operating system simulator** built in C.  
It demonstrates core OS concepts such as:

- **Scheduler** (round-robin, cooperative)
- **In-memory File System**
- **Text Editor** (line-mode)
- **Calculator** (expression parsing + evaluation)
- **Interactive Shell** with UNIX-like commands

---

## 🚀 Build & Run
```bash
make
./mini_os
```

Type `help` inside the shell to see available commands.

---

## 📂 Features
- `ls`, `cd`, `mkdir`, `rm`, `pwd` → simple filesystem operations
- `edit <file>` → line editor (end with `.`)
- `cat <file>` → view file contents
- `calc <expr>` → calculator (e.g., `(2+3*5)/5`)
- `spawn ticker|blink` → demo processes
- `ps`, `kill <pid>`, `tick <n>` → scheduler controls

---

## 🖼️ Example Session
```
$ ls
docs/
$ cd docs
$ cat readme.txt
Welcome to mini_os.
Use 'help' to see commands.
$ calc (2+3*5)/5
5
$ spawn ticker
spawned task 1 (ticker)
$ ps
PID  STATE  NAME
1    0      ticker
$ tick 5
[task 1:ticker] tick 1
[task 1:ticker] tick 2
...
```

---

## 📜 License
MIT License
