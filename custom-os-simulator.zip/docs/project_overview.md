# Project Overview

This project is a **mini UNIX-style operating system simulator** written in C.

## Features
- **Scheduler**: Cooperative round-robin task scheduler.
- **File System**: In-memory hierarchical filesystem.
- **Text Editor**: Line-based editor.
- **Calculator**: Supports arithmetic expressions using shunting-yard algorithm.
- **Shell**: Commands similar to UNIX (ls, cd, mkdir, rm, ps, kill, tick).

This is an **educational project** meant to demonstrate fundamental OS concepts in user space.
